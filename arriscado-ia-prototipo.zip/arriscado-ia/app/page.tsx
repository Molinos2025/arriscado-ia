'use client';
import {useState} from 'react';

type Msg={from:'bot'|'user', text:string};
const starters = [
  ['🚗','Quiero asegurar mi coche'],
  ['🏠','Quiero asegurar mi hogar'],
  ['📋','Quiero revisar mi seguro actual'],
  ['🚐','Seguro de autocaravana'],
  ['👨‍💼','Necesito hablar con un asesor'],
];

export default function Home(){
  const [open,setOpen]=useState(true);
  const [msgs,setMsgs]=useState<Msg[]>([
    {from:'bot',text:'Hola 👋 Soy el asistente virtual de Arriscado. Puedo ayudarte a encontrar el seguro que necesitas, revisar tu póliza o ponerte en contacto con un asesor.'},
  ]);
  const [input,setInput]=useState('');
  const [step,setStep]=useState<'home'|'auto'|'hogar'|'lead'>('home');

  function send(text:string){
    if(!text.trim()) return;
    setMsgs(m=>[...m,{from:'user',text}]);
    const t=text.toLowerCase();
    let reply='Puedo ayudarte con seguros de coche, hogar, autocaravana y otras necesidades. ¿Qué seguro quieres revisar?';
    if(t.includes('coche')||t.includes('auto')){
      setStep('auto');
      reply='Perfecto 🚗. ¿Qué quieres hacer: buscar un nuevo seguro, cambiar de compañía o revisar lo que tienes actualmente?';
    } else if(t.includes('hogar')||t.includes('casa')){
      setStep('hogar');
      reply='Perfecto 🏠. Para orientarte, ¿se trata de tu vivienda habitual, una segunda residencia o una vivienda que alquilas?';
    } else if(t.includes('autocaravana')){
      reply='🚐 Podemos estudiar el seguro de tu autocaravana. Dime marca, modelo, año y si quieres cobertura a terceros, ampliada o todo riesgo.';
    } else if(t.includes('asesor')||t.includes('hablar')){
      setStep('lead');
      reply='Claro. Déjame tus datos y un asesor de Arriscado podrá ponerse en contacto contigo.';
    } else if(step==='auto'){
      setStep('lead');
      reply='Perfecto. Para que Arriscado pueda preparar el estudio, necesito tu nombre y teléfono. También puedes adjuntar tu póliza en la versión completa del sistema.';
    } else if(step==='hogar'){
      setStep('lead');
      reply='Entendido. Para preparar el estudio necesito tu nombre y teléfono. Después podremos solicitar los datos concretos de la vivienda.';
    }
    setTimeout(()=>setMsgs(m=>[...m,{from:'bot',text:reply}]),250);
    setInput('');
  }

  if(!open) return <button className="launcher" onClick={()=>setOpen(true)}>💬</button>;

  return <main>
    <section className="hero">
      <div className="brand">ARRISCADO</div>
      <h1>Seguros claros.<br/><span>Asesoramiento humano.</span></h1>
      <p>Prototipo del asistente virtual para atender clientes, resolver dudas y captar solicitudes de presupuesto.</p>
      <button className="close" onClick={()=>setOpen(false)}>×</button>
    </section>

    <aside className="chat">
      <header>
        <div className="avatar">A</div>
        <div><strong>Arriscado IA</strong><small>Asistente virtual</small></div>
        <div className="online">●</div>
      </header>
      <div className="notice">🤖 Estás hablando con un sistema de inteligencia artificial.</div>
      <div className="messages">
        {msgs.map((m,i)=><div key={i} className={m.from==='bot'?'bot msg':'user msg'}>{m.text}</div>)}
        {msgs.length===1 && <div className="quick">
          {starters.map(([icon,label])=><button key={label} onClick={()=>send(label)}><span>{icon}</span>{label}</button>)}
        </div>}
      </div>
      <div className="composer">
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send(input)} placeholder="Escribe tu consulta..." />
        <button onClick={()=>send(input)}>➤</button>
      </div>
      <footer>Arriscado Correduría de Seguros · Demo</footer>
    </aside>
  </main>
}