# Arriscado IA

Prototipo inicial del asistente virtual de una correduría de seguros.

## Ejecutar
npm install
npm run dev

Después abrir http://localhost:3000

## Próximas fases
- Conectar OpenAI API.
- Base de conocimiento de Arriscado.
- Flujos completos de Auto y Hogar.
- Subida y análisis de pólizas PDF.
- Captación de leads.
- WhatsApp.
- Integración con CRM/ebroker si existe una API disponible.
- Autenticación, consentimiento y protección de datos para producción.
